<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.0.0" 
 xsi:schemaLocation="http://www.opengis.net/sld StyledLayerDescriptor.xsd" 
 xmlns="http://www.opengis.net/sld" 
 xmlns:ogc="http://www.opengis.net/ogc" 
 xmlns:xlink="http://www.w3.org/1999/xlink" 
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <NamedLayer>
    <Name>Poligonos_con_etiquetas</Name>
    <UserStyle>
      <Title>Poligonos amarillos con texto negro y halo</Title>
      <FeatureTypeStyle>
        <Rule>
          <!-- 1. CÓMO SE DIBUJA EL POLÍGONO -->
          <PolygonSymbolizer>
            <Fill>
              <CssParameter name="fill">#fef08a</CssParameter>  <!-- Color de relleno (Ej: Amarillo) -->
              <CssParameter name="fill-opacity">0.6</CssParameter>
            </Fill>
            <Stroke>
              <CssParameter name="stroke">#eab308</CssParameter> <!-- Color del borde -->
              <CssParameter name="stroke-width">2</CssParameter>
            </Stroke>
          </PolygonSymbolizer>

          <!-- 2. CÓMO SE DIBUJA EL TEXTO (ETIQUETAS TIPO QGIS) -->
          <TextSymbolizer>
            <Label>
              <ogc:PropertyName>Razon Social</ogc:PropertyName> <!-- ¡CAMBIA ESTO SEGÚN TU TABLA! -->
            </Label>
            <Font>
              <CssParameter name="font-family">Arial</CssParameter>
              <CssParameter name="font-size">12</CssParameter>
              <CssParameter name="font-weight">bold</CssParameter>
            </Font>
            <LabelPlacement>
              <PointPlacement>
                <AnchorPoint>
                  <AnchorPointX>0.5</AnchorPointX>
                  <AnchorPointY>0.5</AnchorPointY>
                </AnchorPoint>
              </PointPlacement>
            </LabelPlacement>
            <Halo>
              <Radius>2.5</Radius>
              <Fill>
                <CssParameter name="fill">#FFFFFF</CssParameter>
                <CssParameter name="fill-opacity">0.9</CssParameter>
              </Fill>
            </Halo>
            <Fill>
              <CssParameter name="fill">#000000</CssParameter> <!-- Letras Negras -->
            </Fill>
            <!-- Esto fuerza a GeoServer a intentar meter el texto y alinearlo bien -->
            <VendorOption name="autoWrap">60</VendorOption>
            <VendorOption name="polygonAlign">mbr</VendorOption>
            <VendorOption name="goodnessOfFit">0.1</VendorOption> 
          </TextSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>